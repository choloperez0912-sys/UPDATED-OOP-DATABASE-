package com.campus;

/**
 * Student model — mirrors the students table.
 */
public class Student {

    private String studentId;
    private String fullName;
    private int courseId;      // changed from String course
    private int yearLevel;     // changed from String yearLevel
    private String contact;
    private String email;

    public Student() {}

    public Student(String studentId,
                   String fullName,
                   int courseId,
                   int yearLevel,
                   String contact,
                   String email) {

        this.studentId = studentId;
        this.fullName = fullName;
        this.courseId = courseId;
        this.yearLevel = yearLevel;
        this.contact = contact;
        this.email = email;
    }

    // ── Getters & Setters ─────────────────────────────────────────────

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public int getYearLevel() {
        return yearLevel;
    }

    public void setYearLevel(int yearLevel) {
        this.yearLevel = yearLevel;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return studentId + " - " + fullName;
    }
}