package com.campus;

import java.sql.*;
import java.util.*;

public class CourseDAO {

    public List<Course> findAll() throws SQLException {
        String sql = "SELECT course_id, code, name, department FROM courses ORDER BY code";
        List<Course> list = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new Course(
                        rs.getInt("course_id"),
                        rs.getString("code"),
                        rs.getString("name"),
                        rs.getString("department")
                ));
            }
        }
        return list;
    }

    public Optional<Course> findById(int courseId) throws SQLException {
        String sql = "SELECT course_id, code, name, department FROM courses WHERE course_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(new Course(
                        rs.getInt("course_id"), rs.getString("code"),
                        rs.getString("name"), rs.getString("department")
                ));
            }
        }
        return Optional.empty();
    }
}