package com.campus;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * DatabaseInitializer
 *
 * Creates all tables and constraints on first run.
 * Call DatabaseInitializer.initialize() from MainApp.start() before showing any scene.
 */
public class DatabaseInitializer {

    public static void initialize() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            // ── 0. courses (new) ────────────────────────────────────────────────
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS courses (
                    course_id  SERIAL      PRIMARY KEY,
                    code       VARCHAR(20) NOT NULL UNIQUE,
                    name       VARCHAR(100) NOT NULL,
                    department VARCHAR(100)
                )
            """);

            stmt.executeUpdate("""
                INSERT INTO courses (code, name, department) VALUES
                    ('BSIT', 'BS Information Technology',  'College of Computing'),
                    ('BSCS', 'BS Computer Science',        'College of Computing'),
                    ('BSBA', 'BS Business Administration', 'College of Business'),
                    ('BSN',  'BS Nursing',                 'College of Nursing'),
                    ('BSED', 'BS Education',               'College of Education')
                ON CONFLICT (code) DO NOTHING
            """);

            // ── 1. students ─────────────────────────────────────────────────
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS students (
                    student_id  VARCHAR(20)  PRIMARY KEY,
                    full_name   VARCHAR(100) NOT NULL,
                    course_id   INT          NOT NULL REFERENCES courses(course_id) ON UPDATE CASCADE,
                    year_level  SMALLINT     NOT NULL CONSTRAINT chk_year_level CHECK (year_level BETWEEN 1 AND 6),
                    contact     VARCHAR(20)  NOT NULL CONSTRAINT chk_contact CHECK (contact ~ '^[0-9]{10,15}$'),
                    email       VARCHAR(100) NOT NULL UNIQUE CONSTRAINT chk_email CHECK (email ~* '^[^@]+@[^@]+\\.[^@]+$'),
                    created_at  TIMESTAMP    NOT NULL DEFAULT NOW()
                )
            """);

            // ── 2. faculty ───────────────────────────────────────────────────
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS faculty (
                    id         SERIAL       PRIMARY KEY,
                    username   VARCHAR(50)  NOT NULL UNIQUE,
                    password   VARCHAR(255) NOT NULL,
                    full_name  VARCHAR(100),
                    created_at TIMESTAMP    NOT NULL DEFAULT NOW()
                )
            """);

            // Seed default faculty account (password: admin123)
            stmt.executeUpdate("""
                INSERT INTO faculty (username, password, full_name)
                VALUES ('faculty', 'admin123', 'System Administrator')
                ON CONFLICT (username) DO NOTHING
            """);

            // ── 3. attendance ────────────────────────────────────────────────
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS attendance (
                    id          BIGSERIAL    PRIMARY KEY,
                    student_id  VARCHAR(20)  NOT NULL
                                REFERENCES students(student_id) ON DELETE CASCADE,
                    action      VARCHAR(10)  NOT NULL
                                CHECK (action IN ('TIME_IN', 'TIME_OUT')),
                    timestamp   TIMESTAMP    NOT NULL DEFAULT NOW(),
                    exported    BOOLEAN      NOT NULL DEFAULT FALSE
                    )
            """);

            // Index for the common date+student filter used by status checks
            stmt.executeUpdate("""
                CREATE INDEX IF NOT EXISTS idx_attendance_student_date
                ON attendance (student_id, DATE(timestamp))
            """);

            // ── 4. export_log ────────────────────────────────────────────────────
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS export_log (
                    id          BIGSERIAL   PRIMARY KEY,
                    exported_at TIMESTAMP   NOT NULL DEFAULT NOW(),
                    exported_by INT         REFERENCES faculty(id) ON DELETE SET NULL,
                    row_count   INT         NOT NULL DEFAULT 0,
                    file_name   VARCHAR(255)
                )
            """);

// ── 5. export_log_attendance (join table) ───────────────────────────
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS export_log_attendance (
                    export_id     BIGINT NOT NULL REFERENCES export_log(id) ON DELETE CASCADE,
                    attendance_id BIGINT NOT NULL REFERENCES attendance(id) ON DELETE CASCADE,
                    PRIMARY KEY (export_id, attendance_id)
                )
            """);

            System.out.println("[DB] Tables initialized successfully.");

        } catch (SQLException e) {
            System.err.println("[DB] Initialization error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
