package com.campus;

public class Course {

    private int    courseId;
    private String code;
    private String name;
    private String department;

    public Course() {}

    public Course(int courseId, String code, String name, String department) {
        this.courseId   = courseId;
        this.code       = code;
        this.name       = name;
        this.department = department;
    }

    public int    getCourseId()              { return courseId; }
    public void   setCourseId(int v)         { this.courseId = v; }

    public String getCode()                  { return code; }
    public void   setCode(String v)          { this.code = v; }

    public String getName()                  { return name; }
    public void   setName(String v)          { this.name = v; }

    public String getDepartment()            { return department; }
    public void   setDepartment(String v)    { this.department = v; }

    @Override
    public String toString() {
        return code + " – " + name;
    }
}