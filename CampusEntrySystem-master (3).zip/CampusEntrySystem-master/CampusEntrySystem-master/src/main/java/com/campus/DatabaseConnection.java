package com.campus;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {

    private static final String URL;
    private static final String USER;
    private static final String PASS;

    static {
        try (InputStream in =
                     DatabaseConnection.class.getResourceAsStream("/db.properties")) {

            if (in == null) {
                throw new RuntimeException("db.properties not found");
            }

            Properties p = new Properties();
            p.load(in);

            URL = "jdbc:postgresql://"
                    + p.getProperty("db.host")
                    + ":"
                    + p.getProperty("db.port")
                    + "/"
                    + p.getProperty("db.name")
                    + "?sslmode=require&prepareThreshold=0";

            USER = p.getProperty("db.user");
            PASS = p.getProperty("db.password");

        } catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}